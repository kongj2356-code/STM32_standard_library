#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void Key_Init(void)
{
    // ʹ�� GPIOC ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;            // ��������ģʽ
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_13;  // PC1 �� PC13
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);                   // ��ʼ�� GPIOC
}


uint8_t Key_GetNum(void)
{
	uint8_t KeyNum = 0;
   // ����1
	if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_1) == 0)
	{
		Delay_ms(20);
		while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_1) == 0);
		Delay_ms(20);
		KeyNum = 1;
	}

   // ����2
	if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		Delay_ms(20);
		while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == 0);
		Delay_ms(20);
		KeyNum = 2;
	}
	
	return KeyNum;
}
