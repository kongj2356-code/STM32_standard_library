#ifndef __TIMER_H
#define __TIMER_H

extern uint16_t Num;            
void Timer_Init(void);

#endif
