#include "stm32f10x.h"                  // Device header

uint16_t Num;             //拓展main函数中定义变量的作用域

//TIM4 挂载在 APB1总线上
void Timer_Init(void)
{
    // 开启RCC时钟源 - TIM4在APB1总线上
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    // 选择时基单元时钟源——内部时钟选用
    TIM_InternalClockConfig(TIM4);
    
    // 1 HZ --> 1s
    // 配置时基单元(结构体)
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;  
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;   // 计数器模式，向上计数
    TIM_TimeBaseInitStructure.TIM_Period = 10000 - 1;                 // 周期 ARR
    TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;               // PSC 预分频器
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;              // RCR 重复计数器的值
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
    
    
    
    // 配置输出中断到NVIC的通路
    TIM_ClearFlag(TIM4, TIM_FLAG_Update);        //避免刚初始化完就进中断
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    
    // 配置NVIC
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);       // NVIC分组
    
    // 配置NVIC：设置TIM4中断通道的优先级和使能
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;               // TIM4中断通道
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                   // 使能中断通道
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;         // 抢占优先级为2
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;                // 响应优先级为1
    NVIC_Init(&NVIC_InitStructure);
    
    //使能定时器
    TIM_Cmd(TIM4, ENABLE);
}

// TIM4中断处理函数
void TIM4_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
    {
        Num++;
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    }
}